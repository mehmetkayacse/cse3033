#
# Script to test for loop
#
for i in 1 2 3 4 5 
do
echo "Welcome $i times"
done 
